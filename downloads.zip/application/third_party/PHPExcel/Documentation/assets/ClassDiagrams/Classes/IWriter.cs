using System;
using System.Collections.Generic;
using System.Text;

namespace ClassDiagrams
{
    public interface PHPExcel_Writer_IWriter
    {
        PHPExcel writes
        {
            get;
            set;
        }
    }
}
