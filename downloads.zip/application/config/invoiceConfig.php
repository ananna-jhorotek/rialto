<?php
	
	$config['store_id']		= 'shurucampusliveshurucampuslive';
	
?>